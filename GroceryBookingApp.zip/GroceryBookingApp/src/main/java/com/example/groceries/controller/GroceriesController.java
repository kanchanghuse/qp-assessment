package com.example.groceries.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.example.groceries.entity.Cart;
import com.example.groceries.entity.Inventory;
import com.example.groceries.entity.Orders;
import com.example.groceries.entity.Products;
import com.example.groceries.service.GroceriesService;



@RestController
@SessionAttributes("cart")
public class GroceriesController {

	@Autowired
	private GroceriesService service;
	
	//ADMIN RESPONSIBILITIES

	//admin home page
	@GetMapping("/admin/index")
	public ModelAndView adminPage() {
		return new ModelAndView("adminHome");
	}
	
	//add groceries page
	@GetMapping("/admin/addGroceriesPage")
	public ModelAndView addGroceries() {
		return new ModelAndView("addGroceries");
	}
	

	@PostMapping(value="/insertGroceries")
	public String insertGroceries(@RequestBody @ModelAttribute("products") Products product)
	{
		return service.insertGroceries(product);
	}
	
	//remove groceries page
	@GetMapping("/admin/removeGroceriesPage")
	public ModelAndView removeGroceries() {
		return new ModelAndView("removeGroceries");
	}
	

	@PostMapping(value="/deleteGroceries")
	public String deleteGroceries(@RequestBody @ModelAttribute("products") Products product)
	{
		return service.deleteGroceries(product.getProd_id());
	}
	
	//view groceries
	@GetMapping("/admin/viewGroceries")
	public ModelAndView viewGroceries() {
		
		List<Products> productsList = service.viewProducts();
		ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("viewGroceries"); // JSP page name
        modelAndView.addObject("productsList", productsList);
        return modelAndView;
        
	}
	
	//view inventory	
	@GetMapping("/admin/viewInventoryPage")
	public ModelAndView viewInventoryPage() {
		
		List<Inventory> inventory = service.viewInventoryDetails();
		ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("viewInventoryPage"); // JSP page name
        modelAndView.addObject("inventory", inventory);
        return modelAndView;
        
	}
	
	//update groceries page
	@GetMapping("/admin/updateGroceriesPage")
	public ModelAndView updateGroceriesPage() {
		return new ModelAndView("updateGroceries");
	}
	
	@PostMapping(value="/updateGroceries")
	public String updateGroceries(@RequestBody @ModelAttribute("products") Products product)
	{
		return service.updateGroceries(product);
	}
	
	@PostMapping(value="/getProductDetails")
	public ModelAndView getProductDetails(@RequestParam @ModelAttribute("prod_id") String prod_id)
	{
		Products products = service.getProductDetails(prod_id);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("updateItems"); // View name (JSP page)
        modelAndView.addObject("products", products); // Model attribute

        return modelAndView;
	}
	
	
	//USER RESPONSIBILITIES
	
	//user home page
	@GetMapping("/user/index")
	public ModelAndView userPage() {
		return new ModelAndView("userHome");
	}
	
	
	
	  @ModelAttribute("cart")
	    public Cart createCart() {
	        return new Cart();
	    }
	  
	  //add to cart the multiple grocery items
	  @GetMapping("/user/addToCart")
	  public ModelAndView addToCart(@ModelAttribute("cart") Cart cart, @RequestParam("productId") String productId,
			  HttpSession session) {
	        // Retrieve product details based on productId and add it to the cart
	        Products product = service.getProductDetails(productId);

	        int count;
	        ModelAndView modelAndView = new ModelAndView();
	        Cart cartItem = new Cart();
	        cartItem.addItem(product);
	       count= service.saveCart(cartItem,session.getId());
	      if(count>0)
	      {	      
	        List<Products> productsList = service.viewProducts();
	        	     
	        modelAndView.setViewName("bookGroceries"); // JSP page name
	        modelAndView.addObject("productsList", productsList);
	      }
	      else
	      {
	    	   modelAndView.setViewName("errorPage"); 
	      }
	        return modelAndView;
	    }
	  
	//view grocery available item list
	@GetMapping("/user/bookGroceries")
	public ModelAndView bookGroceries() {
		
		List<Products> productsList = service.viewProducts();
		
		ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("bookGroceries"); // JSP page name
        modelAndView.addObject("productsList", productsList);
        return modelAndView;
        
	}
	
	//view cart items and place order
		@GetMapping("/user/checkOutPage")
		public ModelAndView checkOutPage(HttpSession session) {
		
			List<Orders> cart = service.viewCartItems(session);
			 ModelAndView modelAndView = new ModelAndView();
		        modelAndView.setViewName("viewCart"); 
		        modelAndView.addObject("cart", cart);
		        return modelAndView;
		}
	
	//save order 
	@PostMapping("/user/saveOrder")
	public String checkout(@RequestBody @ModelAttribute("orders") Orders order, HttpSession session) {
	    String msg="Some Error Occured..";
	    int result= service.saveOrder(order,session.getId());
	    if(result > 0)
	    	msg ="Order Placed..Thank You..";
	    return msg; 
	}
	
}
