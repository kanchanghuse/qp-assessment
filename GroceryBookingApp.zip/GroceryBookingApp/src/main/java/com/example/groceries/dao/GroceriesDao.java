package com.example.groceries.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DatabaseDriver;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;

import com.example.groceries.entity.Cart;
import com.example.groceries.entity.Inventory;
import com.example.groceries.entity.Orders;
import com.example.groceries.entity.Products;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

@Repository
public class GroceriesDao {
    @Autowired
    JdbcTemplate jdbcTemplate;
    
	public List<Products> viewProducts() {
		 List<Products> products = null;
	
	try
	{
	String sql = "SELECT * FROM products";
    products = jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Products.class));
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	    return products;
		         
	}

	public String insertGroceries(Products obj) {
		
		obj.setProd_id(getSerialNo()+1);
		String msg ="Failed";
		
		try
		{
		   String sql = "INSERT INTO products (prod_id,prod_name , prod_desc, prod_brand, prod_category,prod_price,prod_qty) VALUES (?,?, ?, ?,?,?,?)";
	        int result = jdbcTemplate.update(sql, obj.getProd_id(), obj.getProd_name(),obj.getProd_desc(),obj.getProd_brand(),obj.getProd_category(),
	        		obj.getProd_price(),obj.getProd_qty());
	         
	        if (result > 0) {
	        	String sql2 = "INSERT INTO inventory (prod_id,availble_stock ) values(?,?)";
	        	int result2= jdbcTemplate.update(sql2,obj.getProd_id(),obj.getProd_qty());
	        	if(result2>0)
	            msg="Product Added Successfully";
	        }      
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;
	}

	private int getSerialNo() {
		int value =0;
		try
		{
		String sql = "SELECT max(prod_id) FROM products";
         value =  jdbcTemplate.queryForObject(sql, Integer.class);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
        return value;
	}
	
	

	private int getSerialNoForOrderId() {
		int value =0;
		try
		{
		String sql = "SELECT max(order_id) FROM orders";
		value =  jdbcTemplate.queryForObject(sql, Integer.class);
		}
		catch (Exception e) {
		e.printStackTrace();
		}
        return value;
	}
	private int getSerialNoForCustId() {
		int value=0;
		try
		{
		String sql = "SELECT max(customer_id) FROM orders";
        value =  jdbcTemplate.queryForObject(sql, Integer.class);
		}
		catch (Exception e) {
			e.printStackTrace();
			}
        return value;
	}
	
	public String deleteGroceries(int prod_id) {
		String msg="Failed";
		try
		{
		String sql= "Delete from products where prod_id = ?";
		int result = jdbcTemplate.update(sql,prod_id);
		if(result>0)
		{
			String sql2="Delete from inventory where prod_id=?";
			int result2= jdbcTemplate.update(sql2,prod_id);
			if(result2>0)
			msg="Product deleted successfully";
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			}
		return msg;
	}
	public String updateGroceries(Products prod) {
		String msg="Failed";
		try
		{
		String sql= "update products set prod_name =? ,prod_desc =? ,prod_category =? ,prod_brand=?,prod_price=? ,"
				+ "prod_qty =? where prod_id = ?";
		Object [] params = {prod.getProd_name(),prod.getProd_desc(),prod.getProd_category(),prod.getProd_brand(),prod.getProd_price(),
				prod.getProd_qty(), prod.getProd_id()};
		int result = jdbcTemplate.update(sql,params);
		if(result>0)
		{
			String sql2="update inventory set availble_stock = ? where prod_id=?";
			int result2= jdbcTemplate.update(sql2,prod.getProd_qty(), prod.getProd_id());
			if(result2>0)
			msg="Product updated successfully";
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			}
		return msg;
	}

	public Products getProductDetails(String prod_id) {
		String sql = "SELECT * FROM products WHERE prod_id = ?";
        return jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(Products.class), prod_id);
    
	}

	public List<Inventory> viewInventoryDetails() {
		 List<Inventory> inventoryList=null;
		try
		{
		String sql = "SELECT * FROM inventory";
	    inventoryList = jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Inventory.class));
		}
		catch (Exception e) {
			e.printStackTrace();
			}
		    return inventoryList;
	}

	public int saveCart(Cart cart, String sessionId) {
		 int  count=0;
		 try
		 {
		for(int i = 0 ;i <cart.getItems().size() ;i++)
		{
		   String sql = "INSERT INTO cart (prod_id,session_id,prod_name,prod_price) VALUES (?,?, ?, ?)";
	      int result = jdbcTemplate.update(sql, cart.getItems().get(i).getProd_id(), sessionId,
	        		cart.getItems().get(i).getProd_name(),cart.getItems().get(i).getProd_price());
	      if(result > 0)
	    	  count++;
		}
		 }
		 catch (Exception e) {
			e.printStackTrace();
		}
	      return count;
	}

	public List<Orders> viewCartItems(String sessionId) {
		String sql = "SELECT prod_id,prod_name,prod_price FROM cart where session_id = ? ";
	    List<Orders> cartItems = jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Orders.class),sessionId);

		    return cartItems;
	}

	public int saveOrder(Orders order, String sessionId) {
		int result =0;
		String cust_name = order.getCust_name();
		String cust_add = order.getCust_address();
		String cust_mob = order.getCust_mob();
		int orderId=getSerialNoForOrderId()+1;
		int custID= getSerialNoForCustId()+1;
		
		List<Orders> cartItems = viewCartItems(sessionId);
		try
		{
		for(int i =0;i<cartItems.size();i++)
		{
			
		 String sql = "INSERT INTO orders (order_id,customer_id,prod_id,prod_qty,customer_name,customer_address,customer_mob) VALUES (?,?,?,?,?,?,?)";
	       result = jdbcTemplate.update(sql,orderId,custID,cartItems.get(i).getProd_id(),"1",cust_name,cust_add,cust_mob);
	       
	       
	       if(result > 0)
	       {
	    	   
	    	   String sql2 = "select prod_qty from products where prod_id =? ";
	           Double value =  jdbcTemplate.queryForObject(sql2, Double.class, new Object[] { cartItems.get(i).getProd_id() });
	           
	           
	    	   String sql3 = "update products set prod_qty = ? where prod_id = ? ";
		       result = jdbcTemplate.update(sql3,value-1,cartItems.get(i).getProd_id());
		       	       
	    	   String sql4 = "update inventory set availble_stock = ? where prod_id = ? ";
		       result = jdbcTemplate.update(sql4,value-1,cartItems.get(i).getProd_id());
		       
		       
	       }
		}
		}
		 catch (Exception e) {
				e.printStackTrace();
			}
		return result;
	}


}
