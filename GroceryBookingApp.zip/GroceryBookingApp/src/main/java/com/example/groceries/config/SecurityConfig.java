package com.example.groceries.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig  extends WebSecurityConfigurerAdapter{

	@Autowired
	public void configure_global(AuthenticationManagerBuilder authMgbuild) throws Exception
	{
		authMgbuild.inMemoryAuthentication().withUser("admin").password("{noop}admin").roles("ADMIN");
		authMgbuild.inMemoryAuthentication().withUser("user").password("{noop}user").roles("USER");
	}
	
	@Override
	public void configure(HttpSecurity httpSec) throws Exception
	{
		httpSec.csrf().disable().authorizeRequests().antMatchers("/admin/**").hasAnyRole("ADMIN")
		.and().formLogin();
		
		httpSec.csrf().disable().authorizeRequests().antMatchers("/user/**").hasAnyRole("USER")
		.and().formLogin();
	}
	
}
