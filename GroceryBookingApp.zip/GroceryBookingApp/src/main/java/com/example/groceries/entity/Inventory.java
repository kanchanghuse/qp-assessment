package com.example.groceries.entity;

public class Inventory {

	private int prod_id;
	private int availble_stock;
	
	public int getProd_id() {
		return prod_id;
	}
	public void setProd_id(int prod_id) {
		this.prod_id = prod_id;
	}
	public int getAvailble_stock() {
		return availble_stock;
	}
	public void setAvailble_stock(int availble_stock) {
		this.availble_stock = availble_stock;
	}
	
	
}
