package com.example.groceries.entity;

import java.util.ArrayList;
import java.util.List;

public class Cart {

	 private List<Products> items;

	    public Cart() {
	        items = new ArrayList();
	    }

	    public List<Products> getItems() {
	        return items;
	    }

	    public void addItem(Products product) {
	        items.add(product);
	    }

	    public void removeItem(int index) {
	        items.remove(index);
	    }
}
