package com.example.groceries.service;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.groceries.dao.GroceriesDao;
import com.example.groceries.entity.Cart;
import com.example.groceries.entity.Inventory;
import com.example.groceries.entity.Orders;
import com.example.groceries.entity.Products;

@Service
public class GroceriesService {

	@Autowired
	private GroceriesDao dao;
	public List<Products> viewProducts() {
		return dao.viewProducts();
	}
	public String insertGroceries(Products obj) {
		// TODO Auto-generated method stub
		return dao.insertGroceries(obj);
	}
	public String deleteGroceries(int prod_id) {
		return dao.deleteGroceries(prod_id);
	}
	public String updateGroceries(Products prod) {
		// TODO Auto-generated method stub
		return dao.updateGroceries(prod);
	}
	public Products getProductDetails(String prod_id) {
		// TODO Auto-generated method stub
		return dao.getProductDetails(prod_id);
	}
	public List<Inventory> viewInventoryDetails() {
		return dao.viewInventoryDetails();
	}
	public int saveCart(Cart cart, String sessionId) {
		return dao.saveCart(cart,sessionId);
	}
	public List<Orders> viewCartItems(HttpSession session) {
		return dao.viewCartItems(session.getId());
	}
	public int saveOrder(Orders order, String sessionId) {
		return dao.saveOrder(order,sessionId);
	}

}
